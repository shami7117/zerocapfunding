import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import useLocales from '../../hooks/useLocales';
import styles from './home.module.scss';
import Paragraph from '../../components/Typography/Paragraph/Paragraph';
import Slider from 'react-slick';
import Loader from '../../components/Loading/LoadingScreen';
import toast from 'react-simple-toasts';
import useUser from '../../hooks/useUser';
import Button from '../../components/Button/Button.jsx';
import { get_banner } from '../../api/Endpoints.js';
import { Accordion, AccordionSummary, AccordionDetails } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';

import HomeSec1Banner from '../../assets/images/home/HomeS1Banner.webp';
import HomeS2TopDivider from '../../assets/images/home/HomeS2TopDivider.svg';
import HomeS2AccordionItem1 from '../../assets/images/home/HS2AccordionItem1.webp';
import HomeS2AccordionItem2 from '../../assets/images/home/HS2AccordionItem2.webp';
import HomeS2AccordionItem3 from '../../assets/images/home/HS2AccordionItem3.webp';
import HomeSec3Banner from '../../assets/images/home/HS3Banner.gif';
import HS3Item1 from '../../assets/images/home/HS3Item1.png';
import HS3Item2 from '../../assets/images/home/HS3Item2.png';
import HS3Item3 from '../../assets/images/home/HS3Item3.png';
import HS3Item4 from '../../assets/images/home/HS3Item4.png';
import HS3Item5 from '../../assets/images/home/HS3Item5.png';
import HS3Item6 from '../../assets/images/home/HS3Item6.png';
import HS3Item7 from '../../assets/images/home/HS3Item7.png';
import HS3Item8 from '../../assets/images/home/HS3Item8.png';
import HS3Item9 from '../../assets/images/home/HS3Item9.png';
import HS3Item10 from '../../assets/images/home/HS3Item10.png';
import HS5Item1 from '../../assets/images/home/HS5Item1.png';
import HS5Item2 from '../../assets/images/home/HS5Item2.png';
import HS5Item3 from '../../assets/images/home/HS5Item3.png';
import HS5Item4 from '../../assets/images/home/HS5Item4.png';
import HS5Item5 from '../../assets/images/home/HS5Item5.png';
import HS5Item6 from '../../assets/images/home/HS5Item6.png';
import HS5Item7 from '../../assets/images/home/HS5Item7.png';
import HS5Item8 from '../../assets/images/home/HS5Item8.png';
import HS5Item9 from '../../assets/images/home/HS5Item9.png';
import HS5Item10 from '../../assets/images/home/HS5Item10.png';

const HomePage = () => {
  const { translate } = useLocales();
  const navigate = useNavigate();
  const params = useParams();

  const defalutSetting = {
    dots: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    arrows: false,
  };

  const HS3Slider = {
    dots: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    arrows: false,
  };

  const [loading, setLoading] = useState(false);
  const [bannerData, setBannerData] = useState(null);
  const { get_user } = useUser();
  const [expanded, setExpanded] = useState(false);
  const handleExpandedChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const handleGetData = async () => {
    setLoading(true);
    var resBanner = await get_banner({ type_id: 1 });
    if (resBanner.status) {
      setBannerData(resBanner.data);
      setLoading(false);
    }
  };
  useEffect(() => {
    handleGetData();
  }, []);

  return (
    <React.Fragment>
      {loading ? (
        <div className='customContainer'>
          <Loader />
        </div>
      ) : (
        <React.Fragment>
          <div style={{ overflow: 'hidden' }}>
            <div className={styles.theHome}>
              <div className='customContainer'>
                <div className={styles.theHSection1}>
                  <div className={styles.theHS1TopContent}>
                    <Paragraph
                      color='var(--white-color)'
                      size='50px'
                      bold={600}
                      lineHeight={1.2}
                      style={{
                        paddingBlock: '54px 15px',
                      }}
                    >
                      {translate('Expect more impact from your data.')}
                    </Paragraph>

                    <Paragraph
                      color='var(--white-color)'
                      size='16px'
                      bold={500}
                      lineHeight={1.8}
                      style={{
                        paddingBlock: '5px 42px',
                      }}
                    >
                      {translate(
                        'Edited unites data, insights, and action to drive profitable growth for the world’s leading brands across 1,200+ retailers in over 70 countries.'
                      )}
                    </Paragraph>

                    <Paragraph
                      color='var(--white-color)'
                      size={'16px'}
                      margin={'0 0 48px'}
                    >
                      {translate('DCG ranks Edited')}{' '}
                      <strong>{translate('#1 Digital Shelf Provider!')}</strong>
                    </Paragraph>

                    <div className={styles.theHS1Banner}>
                      <img src={HomeSec1Banner} alt='banner' />
                    </div>
                  </div>
                </div>

                <div className={styles.theHSection2}>
                  <div className={styles.theHS2TopDivider}>
                    <img src={HomeS2TopDivider} alt='top divider' />
                  </div>

                  <div className={styles.theHS2ContentContainer}>
                    <Paragraph
                      color={'#000000'}
                      size={'32px'}
                      bold={500}
                      lineHeight={1.2}
                      textAlign={'center'}
                    >
                      {translate('4k+ brands trust us as their end-to-end')}
                    </Paragraph>
                    <Paragraph
                      color={'#000000'}
                      size={'32px'}
                      bold={500}
                      lineHeight={1.2}
                      textAlign={'center'}
                      margin={'0 0 8px'}
                    >
                      {translate('system for commerce acceleration')}
                    </Paragraph>

                    {/* accordion */}
                    <div>
                      <Accordion
                        className={styles.theHS2Accordian}
                        expanded={expanded === 'faq1'}
                        onChange={handleExpandedChange('faq1')}
                      >
                        <AccordionSummary aria-controls={'Faq1'} id={'Faq1'}>
                          <div
                            className={
                              expanded === 'faq1'
                                ? styles.theALabelLong
                                : styles.theALabelShort
                            }
                          >
                            <Paragraph
                              color={
                                expanded === 'faq1' ? '#237aff' : '#000000'
                              }
                              margin='0 0 5px'
                              bold='500'
                              size='16px'
                              lineHeight={1.5}
                              textTransform={'uppercase'}
                              fontfamily={'var(--secondary-font)'}
                            >
                              {translate('Get an accurate')}
                              <br />
                              {translate('view of the market')}
                            </Paragraph>
                            <div className={styles.theALIcon}>
                              {expanded === 'faq1' ? (
                                <ExpandLessIcon sx={{ color: '#237aff' }} />
                              ) : (
                                <ExpandMoreIcon />
                              )}
                            </div>
                          </div>
                        </AccordionSummary>
                        <AccordionDetails>
                          <div className={styles.theHS2AContent}>
                            <ul>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Analyze, measure and enhance your product positioning, pricing & performance on a foundation of reliable'
                                  )}{' '}
                                  <span style={{ color: '#0270e0' }}>
                                    {translate('digital shelf data')}
                                  </span>{' '}
                                  {translate(
                                    'that spans 1,200+ retailers in 70+ countries'
                                  )}
                                </Paragraph>
                              </li>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Validate decisions, quantify opportunities and drive sales on Amazon using highly accurate 1P & 3P competitor'
                                  )}{' '}
                                  <span style={{ color: '#0270e0' }}>
                                    {translate('sales & market share insights')}
                                  </span>
                                </Paragraph>
                              </li>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Isolate availability issues, track price trends and capture share at specific stores and regions'
                                  )}
                                </Paragraph>
                              </li>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Unlock incremental value and efficiencies by combining our analytics with your other data solutions via our'
                                  )}{' '}
                                  <span style={{ color: '#0270e0' }}>
                                    {translate('Open Commerce Ecosystem')}
                                  </span>
                                </Paragraph>
                              </li>
                            </ul>
                            <div className={styles.theHS2ACBanner}>
                              <img
                                src={HomeS2AccordionItem1}
                                alt='item banner'
                              />
                            </div>
                          </div>
                        </AccordionDetails>
                      </Accordion>
                    </div>

                    <div>
                      <Accordion
                        className={styles.theHS2Accordian}
                        expanded={expanded === 'faq2'}
                        onChange={handleExpandedChange('faq2')}
                      >
                        <AccordionSummary aria-controls={'Faq2'} id={'Faq2'}>
                          <div
                            className={
                              expanded === 'faq2'
                                ? styles.theALabelLong
                                : styles.theALabelShort
                            }
                          >
                            <Paragraph
                              color={
                                expanded === 'faq2' ? '#237aff' : '#000000'
                              }
                              margin='0 0 5px'
                              bold='500'
                              size='16px'
                              lineHeight={1.5}
                              textTransform={'uppercase'}
                              fontfamily={'var(--secondary-font)'}
                            >
                              {translate('Guide your teams')}
                              <br />
                              {translate('to next best actions')}
                            </Paragraph>
                            <div className={styles.theALIcon}>
                              {expanded === 'faq2' ? (
                                <ExpandLessIcon sx={{ color: '#237aff' }} />
                              ) : (
                                <ExpandMoreIcon />
                              )}
                            </div>
                          </div>
                        </AccordionSummary>
                        <AccordionDetails>
                          <div className={styles.theHS2AContent}>
                            <ul>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Get quick, easy answers to your digital shelf questions with'
                                  )}{' '}
                                  <span style={{ color: '#0270e0' }}>
                                    {translate('Ask Edited')}
                                  </span>{' '}
                                  {translate(
                                    ', our chat-based AI assistant that democratizes your data'
                                  )}
                                </Paragraph>
                              </li>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Determine the right organizational structure for your goals and benchmark your eCommerce maturity against industry peers'
                                  )}
                                </Paragraph>
                              </li>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Improve your retailer collaboration with a channel strategy analysis, and then mobilize your team with an'
                                  )}{' '}
                                  <span style={{ color: '#0270e0' }}>
                                    {translate('in-person or virtual workshop')}
                                  </span>{' '}
                                  {translate(
                                    'delivered by our team of experts'
                                  )}
                                </Paragraph>
                              </li>
                            </ul>
                            <div className={styles.theHS2ACBanner}>
                              <img
                                src={HomeS2AccordionItem2}
                                alt='item banner'
                              />
                            </div>
                          </div>
                        </AccordionDetails>
                      </Accordion>
                    </div>

                    <div>
                      <Accordion
                        className={styles.theHS2Accordian}
                        expanded={expanded === 'faq3'}
                        onChange={handleExpandedChange('faq3')}
                      >
                        <AccordionSummary aria-controls={'Faq3'} id={'Faq3'} cs>
                          <div
                            className={
                              expanded === 'faq3'
                                ? styles.theALabelLong
                                : styles.theALabelShort
                            }
                          >
                            <Paragraph
                              color={
                                expanded === 'faq3' ? '#237aff' : '#000000'
                              }
                              margin='0 0 5px'
                              bold='500'
                              size='16px'
                              lineHeight={1.5}
                              textTransform={'uppercase'}
                              fontfamily={'var(--secondary-font)'}
                            >
                              {translate('Go quickly with automations')}
                              <br />
                              {translate('& predictive data')}
                            </Paragraph>
                            <div className={styles.theALIcon}>
                              {expanded === 'faq3' ? (
                                <ExpandLessIcon sx={{ color: '#237aff' }} />
                              ) : (
                                <ExpandMoreIcon />
                              )}
                            </div>
                          </div>
                        </AccordionSummary>
                        <AccordionDetails>
                          <div className={styles.theHS2AContent}>
                            <ul>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Prioritize and improve PDP content, boosting traffic and sales via predictive scoring and generative AI'
                                  )}
                                </Paragraph>
                              </li>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Optimize retail media performance using daily Edited digital shelf signals to trigger more profitable ad buys'
                                  )}
                                </Paragraph>
                              </li>
                              <li>
                                <Paragraph
                                  size={'16px'}
                                  lineHeight={1.5}
                                  fontfamily={'var(--secondary-font)'}
                                  margin={'0 0 15px'}
                                >
                                  {translate(
                                    'Quickly correct Amazon product content and earn back shortage and chargeback fees with'
                                  )}{' '}
                                  <span style={{ color: '#0270e0' }}>
                                    {translate('Autopilot’s')}
                                  </span>{' '}
                                  {translate('automations and workflows')}
                                </Paragraph>
                              </li>
                            </ul>
                            <div className={styles.theHS2ACBanner}>
                              <img
                                src={HomeS2AccordionItem3}
                                alt='item banner'
                              />
                            </div>
                          </div>
                        </AccordionDetails>
                      </Accordion>
                    </div>
                    {/* accordion */}
                  </div>

                  {bannerData != null && bannerData.length > 0 && (
                    <div className={styles.theDCBanner}>
                      <Slider {...defalutSetting}>
                        {bannerData != null &&
                          bannerData.map((res) => (
                            <div>
                              <div className={styles.theDCBImage}>
                                <img src={res.banner_image} alt={''} />
                              </div>
                            </div>
                          ))}
                      </Slider>
                    </div>
                  )}
                </div>

                <div className={styles.theHSection3}>
                  <Paragraph
                    color={'#000'}
                    size={'28px'}
                    bold={500}
                    lineHeight={1.2}
                    textAlign={'center'}
                    margin={'0 0 8px'}
                  >
                    {translate('Transforming commerce analytics')} <br />
                    {translate('with conversational AI')}
                  </Paragraph>
                  <Paragraph
                    color={'#000'}
                    size={'15px'}
                    lineHeight={1.5}
                    textAlign={'center'}
                    margin={'0 0 16px'}
                  >
                    <span style={{ color: '#0270e0' }}>
                      {translate('Ask Edited')}
                    </span>{' '}
                    {translate(
                      'puts commerce insights within reach, empowering users of all levels to decipher data with an intuitive, chat-based AI assistant'
                    )}
                  </Paragraph>
                  <div className={styles.theHS3Banner}>
                    <img src={HomeSec3Banner} alt='analytics' />
                  </div>

                  <Paragraph
                    color={'#000'}
                    size={'32px'}
                    textAlign={'center'}
                    margin={'0 0 8px'}
                  >
                    {translate('Who we help')}
                  </Paragraph>

                  <div className={styles.theHS3ItemSlideWrapper}>
                    <Slider {...HS3Slider}>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item1} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item2} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item3} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item4} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item5} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item6} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item7} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item8} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item9} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS3Item}>
                          <img src={HS3Item10} />
                        </div>
                      </div>
                    </Slider>
                  </div>

                  <div className={styles.theHS3btn}>
                    <Button
                      bg={'transparent'}
                      hvbg={'transparent'}
                      box={'1px solid #000'}
                      br={'5px'}
                      pd={'10px 30px'}
                      onClick={() => {
                        get_user() != null
                          ? navigate('../book-now')
                          : navigate('../login');
                      }}
                    >
                      <Paragraph color={'#000'} size={'13px'}>
                        {translate('View our clients')}
                      </Paragraph>
                    </Button>
                  </div>
                </div>

                <div className={styles.theHSection4}>
                  <Paragraph
                    color={'#000'}
                    size={'36px'}
                    bold={400}
                    textAlign={'center'}
                    margin={'20px 0 0'}
                  >
                    {translate('Customer ROI')}
                  </Paragraph>

                  <div className={styles.theHS4ItemWrapper}>
                    <div className={styles.theHS4Item}>
                      <Paragraph
                        color={'#00d2b7'}
                        size={'36px'}
                        bold={500}
                        lineHeight={'60px'}
                      >
                        2x
                      </Paragraph>
                      <Paragraph
                        color={'#151515'}
                        size={'13px'}
                        lineHeight={'24px'}
                        margin={'15px 0 0'}
                      >
                        {translate('eCommerce growth')}{' '}
                        <strong>{translate('Henkel')}</strong>{' '}
                        {translate(
                          'saw in multiple countries by using Edited scorecards'
                        )}
                      </Paragraph>
                    </div>

                    <div className={styles.theHS4Item}>
                      <Paragraph
                        color={'#00d2b7'}
                        size={'36px'}
                        bold={500}
                        lineHeight={'60px'}
                      >
                        68%
                      </Paragraph>
                      <Paragraph
                        color={'#151515'}
                        size={'13px'}
                        lineHeight={'24px'}
                        margin={'15px 0 0'}
                      >
                        {translate('Sales growth')}{' '}
                        <strong>{translate('Bayer')}</strong>{' '}
                        {translate(
                          'saw from optimizing its Amazon portfolio & product content'
                        )}
                      </Paragraph>
                    </div>

                    <div className={styles.theHS4Item}>
                      <Paragraph
                        color={'#00d2b7'}
                        size={'36px'}
                        bold={500}
                        lineHeight={'60px'}
                      >
                        $500k
                      </Paragraph>
                      <Paragraph
                        color={'#151515'}
                        size={'13px'}
                        lineHeight={'24px'}
                        margin={'15px 0 0'}
                      >
                        {translate('Sales')}{' '}
                        <strong>{translate('Master Lock')}</strong>{' '}
                        {translate(
                          'gained by minimizing out-of-stocks for a single product'
                        )}
                      </Paragraph>
                    </div>

                    <div className={styles.theHS4Item}>
                      <Paragraph
                        color={'#00d2b7'}
                        size={'36px'}
                        bold={500}
                        lineHeight={'60px'}
                      >
                        +28%
                      </Paragraph>
                      <Paragraph
                        color={'#151515'}
                        size={'13px'}
                        lineHeight={'24px'}
                        margin={'15px 0 0'}
                      >
                        {translate('New-to-brand orders for')}{' '}
                        <strong>{translate('Kraft Heinz')}</strong>{' '}
                        {translate(
                          'on Walmart through daily Shelf Intelligent Media optimizations'
                        )}
                      </Paragraph>
                    </div>
                  </div>

                  <div className={styles.theHS4Btn}>
                    <Button
                      bg={'transparent'}
                      hvbg={'transparent'}
                      box={'1px solid #000'}
                      br={'5px'}
                      pd={'10px 30px'}
                      onClick={() => {
                        get_user() != null
                          ? navigate('../book-now')
                          : navigate('../login');
                      }}
                    >
                      <Paragraph color={'#000'} size={'13px'}>
                        {translate('Read success stories')}
                      </Paragraph>
                    </Button>
                  </div>
                </div>

                <div className={styles.theHSection5}>
                  <Paragraph
                    color={'#000'}
                    size={'26px'}
                    bold={500}
                    lineHeight={1.25}
                    textAlign={'center'}
                    margin={'0 8% 0'}
                  >
                    {translate(
                      'Monitoring over 80 million products across thousands of retailer sites and mobile apps in 70+ countries every day'
                    )}
                  </Paragraph>

                  <div className={styles.theHS5ItemSlideWrapper}>
                    <Slider {...HS3Slider}>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item1} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item2} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item3} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item4} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item5} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item6} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item7} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item8} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item9} />
                        </div>
                      </div>
                      <div>
                        <div className={styles.theHS5Item}>
                          <img src={HS5Item10} />
                        </div>
                      </div>
                    </Slider>
                  </div>
                </div>

                <div className={styles.theHSection6}>
                  <div className={styles.theHS6TopDivider}>
                    <img src={HomeS2TopDivider} alt='top divider' />
                  </div>

                  <Paragraph
                    color={'#000'}
                    size={'30px'}
                    bold={500}
                    lineHeight={1.2}
                    textAlign={'center'}
                    margin={'0 15px 0'}
                  >
                    {translate('See why the world’s leading brands trust')}
                    <br />
                    {translate('Edited to accelerate their online sales')}
                  </Paragraph>

                  <div className={styles.theHS6Btn}>
                    <Button
                      bg={'#237aff'}
                      hvbg={'#237aff'}
                      box={'1px solid #237aff'}
                      br={'5px'}
                      pd={'10px 30px'}
                      onClick={() => {
                        get_user() != null
                          ? navigate('../book-now')
                          : navigate('../login');
                      }}
                    >
                      <Paragraph color={'#ffffff'} size={'13px'}>
                        {translate('Request a demo')}
                      </Paragraph>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default HomePage;
